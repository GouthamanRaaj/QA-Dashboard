

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet
 */
public class MyServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
           
           // String user=request.getParameter("user");
            String empid=request.getParameter("empid");
          //  out.println("<h2> Welcome "+user+"</h2>");
           // out.println("<br><h2> Welcome "+empid+"</h2>");
            
            
            // String empid = request.getParameter("empid");
            String fname = request.getParameter("fname");
            String lname = request.getParameter("lname");
            
            
          //  out.println("<br><h2> Welcome "+fname+"</h2>");
            //loading drivers for mysql
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            //
            //
         //   out.println("<br><h2> Welcome "+lname+"</h2>");
            
            
    	//creating connection with the database 
              Connection  con=DriverManager.getConnection
                         ("jdbc:mysql://localhost/db","user2","");

            PreparedStatement ps=con.prepareStatement
                      ("insert into employee values(?,?,?)");

            ps.setString(1, empid);
            ps.setString(2, fname);
            ps.setString(3, lname);
            int i=ps.executeUpdate();
            
              if(i>0)
              {
                out.println("You are sucessfully registered");
              }
              
              Statement stmt = con.createStatement();
              ResultSet rs = stmt.executeQuery("select * from employee");
              out.println("<table border=1 width=50% height=50%>");
              out.println("<tr><th>EmpId</th><th>FirstName</th><th>LastName</th><tr>");
              while (rs.next()) {
                  String n = rs.getString("empid");
                  String nm = rs.getString("fname");
                  String s = rs.getString("lname"); 
                  out.println("<tr><td>" + n + "</td><td>" + nm + "</td><td>" + s + "</td></tr>"); 
              }
              out.println("</table>");
           
            
            
            
        }
        catch(Exception se)
        {
            se.printStackTrace();
        }
        finally {            
            out.close();
        }
    }
}
