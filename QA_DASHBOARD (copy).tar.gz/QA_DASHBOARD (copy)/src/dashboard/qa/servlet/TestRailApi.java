package dashboard.qa.servlet;

//import java.io.BufferedReader;
import java.io.IOException;
//import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gurock.testrail.APIClient;
import com.gurock.testrail.APIException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.util.Iterator;

/*
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
*/
/**
 * Servlet implementation class TestRailApi
 */

@WebServlet("/TestRailApi")
public class TestRailApi extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TestRailApi() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void getStatusUpdate(APIClient client) {

		JSONArray statusArray = null;
		try {
			// get status id's
			statusArray = (JSONArray) client.sendGet("get_statuses");

			// System.out.println(statusArray.toString());

			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/tm_dashboard_testrail", "root", "root");

			@SuppressWarnings("unchecked")
			Iterator<JSONObject> statusMessage = statusArray.listIterator();

			while (statusMessage.hasNext()) {
				JSONObject Message = statusMessage.next();
				String label = (String) Message.get("label");
				String name = (String) Message.get("name");
				Long id = (Long) Message.get("id");

				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("select * from tbl_status_details where status_id=" + id);

				if (!rs.next()) {
					PreparedStatement ps = con.prepareStatement(
							"INSERT INTO `tbl_status_details` (`status_id`,`status_label`,`status_name`) VALUES (?,?,?)");

					ps.setLong(1, id);
					ps.setString(2, label);
					ps.setString(3, name);
					int i = ps.executeUpdate();

					if (i > 0) {
						//System.out.println("You are sucessfully registered");
					}

				}

			}
		} catch (APIException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//System.out.println("You are sucessfully registered");
	}

	protected void getProjectUpdate(APIClient client) {
		JSONArray statusArray = null;

		try {
			// get list of projects
			statusArray = (JSONArray) client.sendGet("get_projects");

			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/tm_dashboard_testrail", "root", "root");

			@SuppressWarnings("unchecked")
			Iterator<JSONObject> statusMessage = statusArray.listIterator();

			while (statusMessage.hasNext()) {

				JSONObject Message = statusMessage.next();
				String name = (String) Message.get("name");
				Long projectId = (Long) Message.get("id");

				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("select * from tbl_project where project_id=" + projectId);

				if (!rs.next()) {
					PreparedStatement ps = con
							.prepareStatement("INSERT INTO `tbl_project` (`project_id`,`project_name`) VALUES (?,?)");

					ps.setLong(1, projectId);
					ps.setString(2, name);
					int i = ps.executeUpdate();

					if (i > 0) {
						//System.out.println("You are sucessfully registered");
					}	

				}
				getMilestoneUpdate(client,projectId);

			}
		} catch (APIException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println("You are sucessfully registered");
	}

	protected void getMilestoneUpdate(APIClient client,Long projectId) {
		JSONArray statusArray = null;
		try {
			// get list of milestone
			statusArray = (JSONArray) client.sendGet("get_milestones/"+projectId);

		//	System.out.println(statusArray.toString());

			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/tm_dashboard_testrail", "root", "root");

			@SuppressWarnings("unchecked")
			Iterator<JSONObject> statusMessage = statusArray.listIterator();

			while (statusMessage.hasNext()) {
				JSONObject Message = statusMessage.next();
				String name = (String) Message.get("name");
				Long milestoneid = (Long) Message.get("id");
				Long projectid = (Long) Message.get("project_id");
				boolean complete = (boolean) Message.get("is_completed");

				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("select * from tbl_milestone_details where milestone_id=" + milestoneid);

				if (!rs.next()) {
					PreparedStatement ps = con.prepareStatement(
							"INSERT INTO `tbl_milestone_details` (`milestone_id`,`milestone_name`,`project_id`,`is_completed`) VALUES (?,?,?,?)");

					ps.setLong(1, milestoneid);
					ps.setString(2, name);
					ps.setLong(3, projectid);
					ps.setBoolean(4, complete);
					int i = ps.executeUpdate();

					if (i > 0) {
					//	System.out.println("You are sucessfully registered");
						getRunListUpdate(client,projectId,milestoneid);
						
					}
				}
				else if(!(rs.getString("milestone_name").equals(name) && rs.getLong("project_id")==projectid && rs.getBoolean("is_completed")==complete)){
					PreparedStatement ps = con.prepareStatement(
							"UPDATE `tbl_milestone_details` SET `milestone_name`= ? ,`project_id`= ? ,`is_completed`=? WHERE milestone_id = "+milestoneid);

					ps.setString(1, name);
					ps.setLong(2, projectid);
					ps.setBoolean(3, complete);
					int i = ps.executeUpdate();

					if (i > 0) {
					//	System.out.println("You are sucessfully registered");
						getRunListUpdate(client,projectId,milestoneid);
						
					}
				}
				else if(complete==false)
				{
					getRunListUpdate(client,projectId,milestoneid);
				}
				
			
				//getRunListUpdate(client,projectId,milestoneid);

				//System.out.println("You are sucessfully registered");
			}
		} catch (APIException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	protected void getUserUpdate(APIClient client) {
		JSONArray statusArray = null;

		try {
			// get list of users
			statusArray = (JSONArray) client.sendGet("get_users");

			// System.out.println(statusArray.toString());

			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/tm_dashboard_testrail", "root", "root");

			@SuppressWarnings("unchecked")
			Iterator<JSONObject> statusMessage = statusArray.listIterator();

			while (statusMessage.hasNext()) {
				JSONObject Message = statusMessage.next();

				Long id = (Long) Message.get("id");
				String name = (String) Message.get("name");
				String email = (String) Message.get("email");

				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("select * from tbl_user_details where user_id=" + id);

				if (!rs.next()) {
					PreparedStatement ps = con.prepareStatement(
							"INSERT INTO `tbl_user_details` (`user_id`,`user_name`,`user_email`) VALUES (?,?,?)");

					ps.setLong(1, id);
					ps.setString(2, name);
					ps.setString(3, email);
					int i = ps.executeUpdate();

					if (i > 0) {
					//	System.out.println("You are sucessfully registered");
					}
				}

			//	System.out.println("reg suc ");

			}
		} catch (APIException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	protected void getRunListUpdate(APIClient client,Long projectId, Long milestoneId) {
		JSONArray statusArray = null;
		//System.out.println("get_runs/"+projectId+"&milestone_id="+milestoneId);
			try {
			// get list of run id
		//	System.out.println("get_runs/"+projectId+"&milestone_id="+milestoneId);
		statusArray = (JSONArray) client.sendGet("get_runs/"+projectId+"&milestone_id="+milestoneId);

			// System.out.println(statusArray.toString());

			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/tm_dashboard_testrail", "root", "root");

			@SuppressWarnings("unchecked")
			Iterator<JSONObject> statusMessage = statusArray.listIterator();

			while (statusMessage.hasNext()) {
				JSONObject Message = statusMessage.next();
				String name = (String) Message.get("name");
				Long assignedToId = (Long) Message.get("assignedto_id");
				Long createdBy = (Long) Message.get("created_by");
				Long runId = (Long) Message.get("id");
				Long milestoneid = (Long) Message.get("milestone_id");
				Long projectid = (Long) Message.get("project_id");
				Long passedCount = (Long) Message.get("passed_count");
				Long failedCount = (Long) Message.get("failed_count");
				Long retestCount = (Long) Message.get("retest_count");
				Long untestedCount = (Long) Message.get("untested_count");
				Long blockedCount = (Long) Message.get("blocked_count");
				boolean complete = (boolean) Message.get("is_completed");

				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("select * from tbl_overview_results where run_id=" + runId);

				if (!rs.next()) {
					PreparedStatement ps = con.prepareStatement(
							"INSERT INTO `tbl_overview_results` (`run_id`,`milestone_id`,`project_id`,`name`,`assigned_id`,`created_by`,"
									+ "`passed_count`,`failed_count`,`retested_count`,`untested_count`,`blocked_count`,`is_completed`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");

					ps.setLong(1, runId);
					ps.setLong(2, milestoneid);
					ps.setLong(3, projectid);
					ps.setString(4, name);
					if(assignedToId==null)
						ps.setLong(5, createdBy);
					else
						ps.setLong(5, assignedToId);
					ps.setLong(6, createdBy);
					ps.setLong(7, passedCount);
					ps.setLong(8, failedCount);
					ps.setLong(9, retestCount);
					ps.setLong(10, untestedCount);
					ps.setLong(11, blockedCount);
					ps.setBoolean(12, complete);

					int i = ps.executeUpdate();

					if (i > 0) {
						//System.out.println("You are sucessfully registered");
						getRunResultUpdate(client,runId,projectId,createdBy);
						
					}
				}
				else if(!(rs.getString("name").equals(name) && rs.getLong("project_id")==projectid && rs.getBoolean("is_completed")==complete
						 && rs.getLong("milestone_id")==milestoneid && rs.getLong("passed_count")==passedCount && rs.getLong("failed_count")==failedCount)){
					
					PreparedStatement ps = con.prepareStatement(
							"UPDATE `tbl_overview_results` SET `milestone_id` = ? , `project_id` = ? , `name`= ? ,"
							+ "`assigned_id`= ? ,`passed_count` = ? ,`failed_count` = ? ,`retested_count` = ?, `untested_count` = ?,"
							+ " `blocked_count` = ?, `is_completed` = ? WHERE run_id = "+runId);

					ps.setLong(1, milestoneid);
					ps.setLong(2, projectid);
					ps.setString(3, name);
					if(assignedToId==null)
						ps.setLong(4, createdBy);
					else
						ps.setLong(4, assignedToId);
					ps.setLong(5, passedCount);
					ps.setLong(6, failedCount);
					ps.setLong(7, retestCount);
					ps.setLong(8, untestedCount);
					ps.setLong(9, blockedCount);
					ps.setBoolean(10, complete);
					int i = ps.executeUpdate();

					if (i > 0) {
					//	System.out.println("You are sucessfully registered");
						getRunResultUpdate(client,runId,projectId,createdBy);
						
					}
				}
				else if(complete==false)
				{
					getRunResultUpdate(client,runId,projectId,createdBy);
				}
							
				//getRunResultUpdate(client,runId,projectId);
				// System.out.println(name+" "+runId+" "+projectId+"
				// "+milestoneId+" "+createdBy+" "+assignedToId);
				// System.out.println(passedCount+" "+failedCount+"
				// "+retestCount+" "+untestedCount+" "+blockedCount);
			}
		} catch (APIException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void getRunResultUpdate(APIClient client, Long runId, Long projectId, Long createdBy)
	{
		JSONArray statusArray = null;

		try {
			// get list of results for run id
			statusArray = (JSONArray) client.sendGet("get_tests/"+runId);

			// System.out.println(statusArray.toString());

			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/tm_dashboard_testrail", "root", "root");

			@SuppressWarnings("unchecked")
			Iterator<JSONObject> statusMessage = statusArray.listIterator();

			while (statusMessage.hasNext()) {
				JSONObject Message = statusMessage.next();

				Long testId = (Long) Message.get("id");
				Long caseId = (Long) Message.get("case_id");
				String caseName = (String) Message.get("title");
				Long typeId = (Long) Message.get("type_id");
				Long assignedToId = (Long) Message.get("assignedto_id");
				Long priorityId = (Long) Message.get("priority_id");
				Long statusId = (Long) Message.get("status_id");
				Long runId1 = (Long) Message.get("run_id");
				
				if(caseId==null)
					caseId=-1L;
				//System.out.println(testResultId+"  "+statusId+"  "+testId+"  "+assignedToId+"  "+projectId);
				Statement stmtcase = con.createStatement();
				ResultSet rscase = stmtcase.executeQuery("select * from tbl_case_details where case_id=" + caseId);
				if(!rscase.next()){
					PreparedStatement pscase = con.prepareStatement("INSERT INTO `tbl_case_details` ( `case_id`,`case_name`,`type_id`,`priority_id`) VALUES (?,?,?,?)");
					pscase.setLong(1,caseId);
					pscase.setString(2, caseName);
					pscase.setLong(3, typeId);
					if(priorityId>5 || priorityId<1 || priorityId==null)
						pscase.setLong(4,3);
					else
						pscase.setLong(4, priorityId);
					int i = pscase.executeUpdate();

					if (i > 0) {
						//System.out.println("You are sucessfully registered");
						}
					}	
				else if(!(rscase.getLong("type_id")==typeId && rscase.getLong("priority_id")==priorityId && rscase.getString("case_name").equals(caseName)))
				{
					PreparedStatement pscase = con.prepareStatement(
							"UPDATE `tbl_case_details` SET `case_name`= ? ,`type_id`= ? ,`priority_id`=? WHERE case_id = "+caseId);

					pscase.setString(1, caseName);
					pscase.setLong(2, typeId);
					if(priorityId>5 || priorityId<1 || priorityId==null)
						pscase.setLong(3,3);
					else
						pscase.setLong(3, priorityId);
					int i = pscase.executeUpdate();

					if (i > 0) {
					//	System.out.println("You are successfully registered");
						
					}
				}
				
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("select * from tbl_test_results where test_id=" + testId);

				if (!rs.next()) {
					
					PreparedStatement ps = con.prepareStatement(
							"INSERT INTO `tbl_test_results` (`test_id`,`case_id`,`assigned_id`,`status_id`,`run_id`) VALUES (?,?,?,?,?)");

					ps.setLong(1, testId);
					ps.setLong(2, caseId);
					if(assignedToId==null)
						ps.setLong(3, createdBy);
					else
						ps.setLong(3, assignedToId);
					
					if(statusId!=null)
						ps.setLong(4, statusId);
					else
						ps.setLong(4, 3);
					ps.setLong(5, runId1);
					
					int i = ps.executeUpdate();

					if (i > 0) {
						//System.out.println("You are sucessfully registered");
						}
					}	
				else if(!(rs.getLong("case_id")==caseId && rs.getLong("status_id")==statusId)){
					
					PreparedStatement ps = con.prepareStatement(
							"UPDATE `tbl_test_results` SET `case_id`= ? ,`status_id`= ? WHERE test_id = "+testId);

					ps.setLong(1, caseId);
					ps.setLong(2, statusId);
					int i = ps.executeUpdate();

					if (i > 0) {
					//	System.out.println("You are successfully registered");
						
					}
				}
			}

		} catch (APIException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	protected void getPriorityUpdate(APIClient client)
	{
		JSONArray statusArray = null;
		try {
			// get status id's
			statusArray = (JSONArray) client.sendGet("get_priorities");

			// System.out.println(statusArray.toString());

			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/tm_dashboard_testrail", "root", "root");

			@SuppressWarnings("unchecked")
			Iterator<JSONObject> statusMessage = statusArray.listIterator();

			while (statusMessage.hasNext()) {
				JSONObject Message = statusMessage.next();
				String name = (String) Message.get("name");
				Long id = (Long) Message.get("id");

				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("select * from tbl_priorities where priority_id=" + id);

				if (!rs.next()) {
					PreparedStatement ps = con.prepareStatement(
							"INSERT INTO `tbl_priorities` (`priority_id`,`name`) VALUES (?,?)");

					ps.setLong(1, id);
					ps.setString(2, name);
					int i = ps.executeUpdate();

					if (i > 0) {
						//System.out.println("You are sucessfully registered");
					}

				}

			}
		} catch (APIException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//System.out.println("You are sucessfully registered");
	}
	protected void getCaseTypeUpdate(APIClient client)
	{
		JSONArray statusArray = null;
		try {
			// get status id's
			statusArray = (JSONArray) client.sendGet("get_case_types");

			// System.out.println(statusArray.toString());

			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/tm_dashboard_testrail", "root", "root");

			@SuppressWarnings("unchecked")
			Iterator<JSONObject> statusMessage = statusArray.listIterator();

			while (statusMessage.hasNext()) {
				JSONObject Message = statusMessage.next();
				String name = (String) Message.get("name");
				Long id = (Long) Message.get("id");

				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("select * from tbl_case_types where type_id=" + id);

				if (!rs.next()) {
					PreparedStatement ps = con.prepareStatement(
							"INSERT INTO `tbl_case_types` (`type_id`,`type_name`) VALUES (?,?)");

					ps.setLong(1, id);
					ps.setString(2, name);
					int i = ps.executeUpdate();

					if (i > 0) {
						//System.out.println("You are sucessfully registered");
					}

				}

			}
		} catch (APIException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//System.out.println("You are sucessfully registered");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		

		APIClient client = new APIClient("https://tenmarks.testrail.com/");
		client.setUser("tenmarks_automation_user@amazon.com");
		client.setPassword("IbCLepONUYou.qfKs0Zm-D3UaI8S3bNSPUGTZrIe9");
		
		try {
			getPriorityUpdate(client);
			
			getCaseTypeUpdate(client);
			
			getStatusUpdate(client);
			
			getUserUpdate(client);

			getProjectUpdate(client);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		response.sendRedirect("Testrail.jsp"); 

	}

}
